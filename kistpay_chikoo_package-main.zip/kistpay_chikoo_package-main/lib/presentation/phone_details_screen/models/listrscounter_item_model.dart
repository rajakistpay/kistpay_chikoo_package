/// This class is used in the [listrscounter_item_widget] screen.
class ListrscounterItemModel {
  String? id = "";
}
