class ProductSummaryItemModel {
  String yourselectedphoTxt;
  String nameTxt;
  String? id;

  ProductSummaryItemModel({
    this.yourselectedphoTxt = "",
    this.nameTxt = "",
    this.id,
  });
}