class ImageConstant {
  static String imgTelevision = 'packages/kistpay_chikoo/assets/images/img_television.svg';

  static String imgCar = 'packages/kistpay_chikoo/assets/images/img_car.svg';

  static String imgArrowdownGray70001 =
      'packages/kistpay_chikoo/assets/images/img_arrowdown_gray_700_01.svg';

  static String imgArrowleft = 'packages/kistpay_chikoo/assets/images/img_arrowleft.svg';

  static String imgArrowdown = 'packages/kistpay_chikoo/assets/images/img_arrowdown.svg';

  static String imgArrowup = 'packages/kistpay_chikoo/assets/images/img_arrowup.svg';

  static String imgIconGray80001 = 'packages/kistpay_chikoo/assets/images/img_icon_gray_800_01.svg';

  static String imgRedminote11 = 'packages/kistpay_chikoo/assets/images/img_redminote11.png';

  static String imgArrowright = 'packages/kistpay_chikoo/assets/images/img_arrowright.svg';

  static String imgArrowleftIndigo400 =
      'packages/kistpay_chikoo/assets/images/img_arrowleft_indigo_400.svg';

  static String imgImage57 = 'packages/kistpay_chikoo/assets/images/img_image57.png';

  static String imgToggleradiobu = 'packages/kistpay_chikoo/assets/images/img_toggleradiobu.svg';

  static String imgToggleradiobuWhiteA700 =
      'packages/kistpay_chikoo/assets/images/img_toggleradiobu_white_a700.svg';

  static String imgIcon = 'packages/kistpay_chikoo/assets/images/img_icon.svg';

  static String imgSignal = 'packages/kistpay_chikoo/assets/images/img_signal.svg';

  static String imgG10 = 'packages/kistpay_chikoo/assets/images/img_g10.svg';

  static String imgFile = 'packages/kistpay_chikoo/assets/images/img_file.svg';

  static String imgBluetoothicon = 'packages/kistpay_chikoo/assets/images/img_bluetoothicon.svg';

  static String imgUndrawconfirmed81ex1 =
      'packages/kistpay_chikoo/assets/images/img_undrawconfirmed81ex1.svg';

  static String imgRectangle6 = 'packages/kistpay_chikoo/assets/images/img_rectangle6.svg';

  static String imageNotFound = 'packages/kistpay_chikoo/assets/images/image_not_found.png';
  static String payfast = 'packages/kistpay_chikoo/assets/images/payfast.png';
  static String easypaisa = 'packages/kistpay_chikoo/assets/images/easypaisa.png';
  static String jazz = 'packages/kistpay_chikoo/assets/images/jazzcash.png';
  static String paymentsIcon = 'packages/kistpay_chikoo/assets/images/payments.svg';
  static String newApplicationIcon = 'packages/kistpay_chikoo/assets/images/newApplocation.svg';
}
